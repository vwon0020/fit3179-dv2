Put your scanned hand-drawn sketch here as sketch.pdf
